<?=script_tag(base_url('assets/vendor/libs/jquery/jquery.js'))."\n"?>
<?=script_tag(base_url('assets/js/config.js'))?>
<?=script_tag(base_url('assets/vendor/js/helpers.js'))?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<!--<?=link_tag('https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap')."\n";?>-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>

<?=link_tag(base_url('assets/vendor/fonts/boxicons.css'))."\n";?>
<?=link_tag(base_url('assets/vendor/css/core.css'))."\n";?>
<?=link_tag(base_url('assets/vendor/css/theme-default.css'))."\n";?>
<?=link_tag(base_url('assets/css/demo.css'))."\n";?>
<?=link_tag(base_url('assets/common.css'))."\n";?>
<?=link_tag(base_url('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css'))."\n";?>
<?=link_tag(base_url('assets/vendor/libs/apex-charts/apex-charts.css'))."\n";?>
<?=link_tag(base_url('assets/select2/css/select2.min.css'))."\n";?>
<?=link_tag(base_url('assets/select2-bootstrap4-theme/select2-bootstrap4.min.css'))."\n";?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" />
<?=link_tag(base_url('assets/toastr/toastr.min.css'))."\n";?>
<?=link_tag(base_url('assets/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css'))."\n";?>

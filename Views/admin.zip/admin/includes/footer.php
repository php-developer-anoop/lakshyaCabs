<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
    <div class="mb-2 mb-md-0">
      ©
      <script>
        document.write(new Date().getFullYear());
      </script>
      , All Rights Reserved By 
      <a href="https://duplextech.com/" target="_anoop"  class="footer-link fw-medium">Duplex Technologies</a>
    </div>
  </div>
</footer>
<div class="content-backdrop fade"></div>
</div>
</div>
</div>
<div class="layout-overlay layout-menu-toggle"></div>
</div>

<div class="modal fade" id="confirmModal">
	<div class="modal-dialog modal-sm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-body statusmodal p-0">
				<div class="modal-header">
					<h4>Confirm</h4>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modeltxt">
				    <p>Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam.</p>
				    <div class="mdlbtns">
				        <button class="btn-green btnyes">Yes</button>
				        <button class="btn-magenta btnno">No</button>
				    </div>
				</div>
			</div>
		</div>
	</div>
</div>






<!--<div class="modal fade" id="faremodal">-->
<!--	<div class="modal-dialog modal-sm modal-dialog-centered">-->
<!--		<div class="modal-content">-->
<!--			<div class="modal-body statusmodal p-0">-->
<!--				<div class="modal-header">-->
<!--					<h4>Fare Summary (Updated on: 12/01/2024)</h4>-->
<!--					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>-->
<!--				</div>-->
<!--				<div class="modeltxt faresum">-->
<!--				    <div class="farerow">-->
<!--				        <p>Trip Type:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>Outstation</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Base fare:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>6300.00</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Minimum KMs:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>80</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>DA:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>300</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Night Charge:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>300</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Night Charge from:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>16/01/2024</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Night Charge to:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>16/01/2024</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Toll:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>80.00</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Parking Charge:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>80.00</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>State tax:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>80.00</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				    <div class="farerow">-->
<!--				        <p>Airport parking:</p>-->
<!--				        <div class="answr">-->
<!--				            <p>80.00</p>-->
<!--				        </div>-->
<!--				    </div>-->
<!--				</div>-->
<!--			</div>-->
<!--		</div>-->
<!--	</div>-->
<!--</div>-->












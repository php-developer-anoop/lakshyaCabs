<div class="content-wrapper">
  <div class="container-xxl flex-grow-1 container-p-y">
    <nav aria-label="breadcrumb" class="d-flex flex-row justify-content-between ">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="javascript:void(0);">Home</a>
        </li>
        <li class="breadcrumb-item">
          <a href="javascript:void(0);"><?=$menu?></a>
        </li>
        <li class="breadcrumb-item active"><?=$title?></li>
      </ol>
    </nav>
    <div class="row">
      <div class="col-xxl">
        <div class="card mb-4">
          <div class="card-body">
               <div class="dflexbtwn">
                   <nav class="bookingtabs">
                       <button class="bktab active">New Booking</button>
                       <button class="bktab">Driver Pending</button>
                       <button class="bktab">Driver Assign</button>
                       <button class="bktab">In progress</button>
                       <button class="bktab">Completed</button>
                   </nav>
                   <div class="cstmselect">
                       <select class="form-select">
                           <option disabled selected>Custom</option>
                           <option>One</option>
                           <option>Two</option>
                       </select>
                   </div>
               </div>
               <div class="dflexbtwn mt-4">
                  <div class="bkdate_selct">
                      <div class="cstm_bookdate">
                          <i class="fa-regular fa-calendar"></i>
                          <input type="text" class="form-control" placeholder="From date - DD/MM/YYYY">
                      </div>
                      <div class="cstm_bookdate">
                          <i class="fa-regular fa-calendar"></i>
                          <input type="text" class="form-control" placeholder="To date - DD/MM/YYYY">
                      </div>
                      <div class="bkselect">
                          <select name="" id="" class="form-control select2" required>
                              <option value="">Select operation city</option>
                          </select>
                      </div>
                  </div>
                  <div class="filtrbtn">
                      <button type="submit">Search</button>
                  </div>
               </div>
               
               <div class="mt-4 table-responsive text-nowrap">
                  <table id="tabless" class="table bookingtable mb-0">
                      <thead>
                          <tr>
                              <th>Sr. No.</th>
                              <th>Booking ID</th>
                              <th>Customer</th>
                              <th>Trip Detail</th>
                              <th>Driver Detail</th>
                              <th>Vendor Detail</th>
                              <th>Status</th>
                              <th style="min-width:200px;">Action</th>
                          </tr>
                      </thead>
                      <tbody>
                          <tr>
                              <td>1</td>
                              <td>
                                  <div class="bkid">
                                      <p>LK20241340</p>
                                      <p class="triptype text-purple">Outstation</p>
                                  </div>
                              </td>
                              <td>
                                 <div class="cstmrdtl">
                                     <p class="uid text-red">UID:4008</p>
                                     <p>Name: Laksham B</p>
                                     <p class="text-purple">Mob: 9978948906</p>
                                     <p class="text-blue">Email: laxman.b@xyz.com</p>
                                     <p>GSTNo. : -</p>
                                 </div>
                              </td>
                              <td>
                                  <div class="trpdtl">
                                      <p>Pick up: Vadodara</p>
                                      <p>Drop: Vadodara</p>
                                      <p>Pickup Date: 03/01/2024, 08:15 am</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="drivrdtl">
                                      <p>Arun K</p>
                                      <p>+91-9101001010</p>
                                      <p>UP 32 AK 1234</p>
                                      <p>Vehicle type: Hatchback</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="vndrdtl">
                                      <p>Cab Pvt. Ltd.</p>
                                      <p>+91-9101101010</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="status">
                                       <p class="bookingtag active">Active</p>
                                       <p>Driver Assigned</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="actnswrapr">
                                      <button class="btn actnbtn btn-blue" data-toggle="tooltip" data-placement="top" title="Confirm" title="">
                                        <i class="fa-regular fa-circle-check"></i>
                                      </button>
                                      <button class="btn actnbtn btn-voilet" data-toggle="tooltip" data-placement="top" title="Assign Driver" title="">
                                         <i class="fa-solid fa-user-plus"></i>
                                      </button>
                                      <button class="btn actnbtn btn-magenta" data-toggle="tooltip" data-placement="top" title="Close Duty" title="">
                                        <a style="color:#fff;" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#confirmModal">
                                             <i class="fa-regular fa-circle-xmark"></i>
                                        </a> 
                                      </button>
                                      <button class="btn actnbtn btn-green" data-toggle="tooltip" data-placement="top" title="Fare Summary" title="">
                                        <a style="color:#fff;" class="showfaresum" href="javascript:void(0);">
                                           <i class="fa-solid fa-indian-rupee-sign"></i>
                                        </a>
                                        <div class="faresum_box" style="display:none;">
                                            <div class="modal-body faremodal">
                                				<div class="modal-header">
                                					<h4>Fare Summary (Updated on: 12/01/2024)</h4>
                                					<a href="#" class="closebtn"> <i class="fa-regular fa-circle-xmark"></i> </a>
                                				</div>
                                				<div class="modeltxt faresum">
                                				    <div class="farerow">
                                				        <p>Trip Type:</p>
                                				        <div class="answr">
                                				            <p>Outstation</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Base fare:</p>
                                				        <div class="answr">
                                				            <p>6300.00</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Minimum KMs:</p>
                                				        <div class="answr">
                                				            <p>80</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>DA:</p>
                                				        <div class="answr">
                                				            <p>300</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Night Charge:</p>
                                				        <div class="answr">
                                				            <p>300</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Night Charge from:</p>
                                				        <div class="answr">
                                				            <p>16/01/2024</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Night Charge to:</p>
                                				        <div class="answr">
                                				            <p>16/01/2024</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Toll:</p>
                                				        <div class="answr">
                                				            <p>80.00</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Parking Charge:</p>
                                				        <div class="answr">
                                				            <p>80.00</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>State tax:</p>
                                				        <div class="answr">
                                				            <p>80.00</p>
                                				        </div>
                                				    </div>
                                				    <div class="farerow">
                                				        <p>Airport parking:</p>
                                				        <div class="answr">
                                				            <p>80.00</p>
                                				        </div>
                                				    </div>
                                				</div>
                                			</div>
                                        </div>
                                      </button>
                                      <button class="btn actnbtn btn-orange" data-toggle="tooltip" data-placement="top" title="Edit" title="">
                                        <i class="fa-regular fa-edit"></i>
                                      </button>
                                      <button class="btn actnbtn btn-lgreen" data-toggle="tooltip" data-placement="top" title="View" title="">
                                          <i class="fa-regular fa-eye"></i>
                                      </button>
                                      <button class="btn actnbtn btn-dblue" data-toggle="tooltip" data-placement="top" title="Print Duty Slip" title="">
                                        <i class="fa-solid fa-print"></i>
                                      </button>
                                      <button class="btn actnbtn btn-red" data-toggle="tooltip" data-placement="top" title="Cancel" title="">
                                          <i class="fa-solid fa-ban"></i>
                                      </button>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td>2</td>
                              <td>
                                  <div class="bkid">
                                      <p>LK20241340</p>
                                      <p class="triptype text-purple">Outstation</p>
                                  </div>
                              </td>
                              <td>
                                 <div class="cstmrdtl">
                                     <p class="uid text-red">UID:4008</p>
                                     <p>Name: Laksham B</p>
                                     <p class="text-purple">Mob: 9978948906</p>
                                     <p class="text-blue">Email: laxman.b@xyz.com</p>
                                     <p>GSTNo. : -</p>
                                 </div>
                              </td>
                              <td>
                                  <div class="trpdtl">
                                      <p>Pick up: Vadodara</p>
                                      <p>Drop: Vadodara</p>
                                      <p>Pickup Date: 03/01/2024, 08:15 am</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="drivrdtl">
                                      <p>Arun K</p>
                                      <p>+91-9101001010</p>
                                      <p>UP 32 AK 1234</p>
                                      <p>Vehicle type: Hatchback</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="vndrdtl">
                                      <p>Cab Pvt. Ltd.</p>
                                      <p>+91-9101101010</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="status">
                                       <p class="bookingtag active">Active</p>
                                       <p>Driver Assigned</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="actnswrapr">
                                      <button class="btn actnbtn btn-blue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-circle-check"></i>
                                      </button>
                                      <button class="btn actnbtn btn-voilet" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-solid fa-user-plus"></i>
                                      </button>
                                      <button class="btn actnbtn btn-magenta" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-regular fa-circle-xmark"></i>
                                      </button>
                                      <button class="btn actnbtn btn-green" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-indian-rupee-sign"></i>
                                      </button>
                                      <button class="btn actnbtn btn-orange" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-edit"></i>
                                      </button>
                                      <button class="btn actnbtn btn-lgreen" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-regular fa-eye"></i>
                                      </button>
                                      <button class="btn actnbtn btn-dblue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-solid fa-print"></i>
                                      </button>
                                      <button class="btn actnbtn btn-red" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-ban"></i>
                                      </button>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td>3</td>
                              <td>
                                  <div class="bkid">
                                      <p>LK20241340</p>
                                      <p class="triptype text-purple">Outstation</p>
                                  </div>
                              </td>
                              <td>
                                 <div class="cstmrdtl">
                                     <p class="uid text-red">UID:4008</p>
                                     <p>Name: Laksham B</p>
                                     <p class="text-purple">Mob: 9978948906</p>
                                     <p class="text-blue">Email: laxman.b@xyz.com</p>
                                     <p>GSTNo. : -</p>
                                 </div>
                              </td>
                              <td>
                                  <div class="trpdtl">
                                      <p>Pick up: Vadodara</p>
                                      <p>Drop: Vadodara</p>
                                      <p>Pickup Date: 03/01/2024, 08:15 am</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="drivrdtl">
                                      <p>Arun K</p>
                                      <p>+91-9101001010</p>
                                      <p>UP 32 AK 1234</p>
                                      <p>Vehicle type: Hatchback</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="vndrdtl">
                                      <p>Cab Pvt. Ltd.</p>
                                      <p>+91-9101101010</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="status">
                                       <p class="bookingtag active">Active</p>
                                       <p>Driver Assigned</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="actnswrapr">
                                      <button class="btn actnbtn btn-blue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-circle-check"></i>
                                      </button>
                                      <button class="btn actnbtn btn-voilet" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-solid fa-user-plus"></i>
                                      </button>
                                      <button class="btn actnbtn btn-magenta" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-regular fa-circle-xmark"></i>
                                      </button>
                                      <button class="btn actnbtn btn-green" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-indian-rupee-sign"></i>
                                      </button>
                                      <button class="btn actnbtn btn-orange" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-edit"></i>
                                      </button>
                                      <button class="btn actnbtn btn-lgreen" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-regular fa-eye"></i>
                                      </button>
                                      <button class="btn actnbtn btn-dblue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-solid fa-print"></i>
                                      </button>
                                      <button class="btn actnbtn btn-red" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-ban"></i>
                                      </button>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td>4</td>
                              <td>
                                  <div class="bkid">
                                      <p>LK20241340</p>
                                      <p class="triptype text-purple">Outstation</p>
                                  </div>
                              </td>
                              <td>
                                 <div class="cstmrdtl">
                                     <p class="uid text-red">UID:4008</p>
                                     <p>Name: Laksham B</p>
                                     <p class="text-purple">Mob: 9978948906</p>
                                     <p class="text-blue">Email: laxman.b@xyz.com</p>
                                     <p>GSTNo. : -</p>
                                 </div>
                              </td>
                              <td>
                                  <div class="trpdtl">
                                      <p>Pick up: Vadodara</p>
                                      <p>Drop: Vadodara</p>
                                      <p>Pickup Date: 03/01/2024, 08:15 am</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="drivrdtl">
                                      <p>Arun K</p>
                                      <p>+91-9101001010</p>
                                      <p>UP 32 AK 1234</p>
                                      <p>Vehicle type: Hatchback</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="vndrdtl">
                                      <p>Cab Pvt. Ltd.</p>
                                      <p>+91-9101101010</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="status">
                                       <p class="bookingtag active">Active</p>
                                       <p>Driver Assigned</p>
                                  </div>
                              </td>
                              <td>
                                  <div class="actnswrapr">
                                      <button class="btn actnbtn btn-blue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-circle-check"></i>
                                      </button>
                                      <button class="btn actnbtn btn-voilet" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-solid fa-user-plus"></i>
                                      </button>
                                      <button class="btn actnbtn btn-magenta" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                         <i class="fa-regular fa-circle-xmark"></i>
                                      </button>
                                      <button class="btn actnbtn btn-green" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-indian-rupee-sign"></i>
                                      </button>
                                      <button class="btn actnbtn btn-orange" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-regular fa-edit"></i>
                                      </button>
                                      <button class="btn actnbtn btn-lgreen" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-regular fa-eye"></i>
                                      </button>
                                      <button class="btn actnbtn btn-dblue" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                        <i class="fa-solid fa-print"></i>
                                      </button>
                                      <button class="btn actnbtn btn-red" data-toggle="tooltip" data-placement="top" title="Tooltip on top" title="">
                                          <i class="fa-solid fa-ban"></i>
                                      </button>
                                  </div>
                              </td>
                          </tr>
                          
                      </tbody>
                  </table>
                </div>
               
          </div>
        </div>
      </div>
    </div>
  </div>
</div>